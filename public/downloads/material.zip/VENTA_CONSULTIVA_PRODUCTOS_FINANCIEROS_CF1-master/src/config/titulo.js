module.exports = 'Venta consultiva de productos financieros'
